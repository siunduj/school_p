<?php

namespace App\Repositories\Package;

use App\Repositories\Base\BaseInterface;

interface PackageInterface extends BaseInterface {

}
