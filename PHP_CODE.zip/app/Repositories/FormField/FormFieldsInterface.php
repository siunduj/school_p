<?php

namespace App\Repositories\FormField;

use App\Repositories\Base\BaseInterface;

/**
 * @method defaultModel()
 */
interface FormFieldsInterface extends BaseInterface {

}
