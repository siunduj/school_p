<?php

namespace App\Repositories\Subject;

use App\Repositories\Base\BaseInterface;

interface SubjectInterface extends BaseInterface {

}
