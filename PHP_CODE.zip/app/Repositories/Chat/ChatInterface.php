<?php

namespace App\Repositories\Chat;

use App\Repositories\Base\BaseInterface;

interface ChatInterface extends BaseInterface {

}
