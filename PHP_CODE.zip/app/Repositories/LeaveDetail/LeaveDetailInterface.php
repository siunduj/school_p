<?php

namespace App\Repositories\LeaveDetail;

use App\Repositories\Base\BaseInterface;

interface LeaveDetailInterface extends BaseInterface {

}
