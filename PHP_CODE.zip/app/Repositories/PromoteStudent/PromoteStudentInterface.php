<?php

namespace App\Repositories\PromoteStudent;

use App\Repositories\Base\BaseInterface;

interface PromoteStudentInterface extends BaseInterface {

}
