<?php

namespace App\Repositories\Assignment;

use App\Repositories\Base\BaseInterface;

interface AssignmentInterface extends BaseInterface {

}
