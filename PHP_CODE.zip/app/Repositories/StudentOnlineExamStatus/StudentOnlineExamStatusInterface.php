<?php

namespace App\Repositories\StudentOnlineExamStatus;

use App\Repositories\Base\BaseInterface;

interface StudentOnlineExamStatusInterface extends BaseInterface {

}
