<?php

namespace App\Repositories\PayrollSetting;

use App\Repositories\Base\BaseInterface;

interface PayrollSettingInterface extends BaseInterface {

}
