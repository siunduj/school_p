<?php

namespace App\Repositories\SubscriptionBill;

use App\Repositories\Base\BaseInterface;

interface SubscriptionBillInterface extends BaseInterface {
    
}
