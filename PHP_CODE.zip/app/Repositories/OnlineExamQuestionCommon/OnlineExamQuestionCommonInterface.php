<?php

namespace App\Repositories\OnlineExamQuestionCommon;

use App\Repositories\Base\BaseInterface;

interface OnlineExamQuestionCommonInterface extends BaseInterface {

}
