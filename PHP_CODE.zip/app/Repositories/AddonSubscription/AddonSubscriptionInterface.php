<?php

namespace App\Repositories\AddonSubscription;

use App\Repositories\Base\BaseInterface;

interface AddonSubscriptionInterface extends BaseInterface {
    public function default();
}
