<?php

namespace App\Repositories\OnlineExamQuestionChoice;

use App\Repositories\Base\BaseInterface;

interface OnlineExamQuestionChoiceInterface extends BaseInterface {

}
