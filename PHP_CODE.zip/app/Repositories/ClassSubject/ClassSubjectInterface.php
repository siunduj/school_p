<?php

namespace App\Repositories\ClassSubject;

use App\Repositories\Base\BaseInterface;

interface ClassSubjectInterface extends BaseInterface {

}
