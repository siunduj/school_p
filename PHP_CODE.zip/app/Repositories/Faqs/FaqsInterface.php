<?php

namespace App\Repositories\Faqs;

use App\Repositories\Base\BaseInterface;

interface FaqsInterface extends BaseInterface {

}
