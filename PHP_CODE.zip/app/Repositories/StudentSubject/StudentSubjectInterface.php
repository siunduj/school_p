<?php

namespace App\Repositories\StudentSubject;

use App\Repositories\Base\BaseInterface;

interface StudentSubjectInterface extends BaseInterface {

}
