<?php

namespace App\Repositories\ExtraSchoolData;

use App\Repositories\Base\BaseInterface;

interface ExtraSchoolDataInterface extends BaseInterface {

}
