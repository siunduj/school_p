<?php

namespace App\Repositories\ExtraFormField;

use App\Repositories\Base\BaseInterface;

interface ExtraFormFieldsInterface extends BaseInterface {

}
