<?php

namespace App\Repositories\Gallery;

use App\Repositories\Base\BaseInterface;

interface GalleryInterface extends BaseInterface {

}
