<?php

namespace App\Repositories\DatabaseBackup;

use App\Repositories\Base\BaseInterface;

interface DatabaseBackupInterface extends BaseInterface {

}
