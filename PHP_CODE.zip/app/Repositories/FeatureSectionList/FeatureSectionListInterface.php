<?php

namespace App\Repositories\FeatureSectionList;

use App\Repositories\Base\BaseInterface;

interface FeatureSectionListInterface extends BaseInterface {

}
