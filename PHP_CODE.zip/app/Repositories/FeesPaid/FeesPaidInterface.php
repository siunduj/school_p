<?php

namespace App\Repositories\FeesPaid;

use App\Repositories\Base\BaseInterface;

interface FeesPaidInterface extends BaseInterface {

}
