<?php

namespace App\Repositories\Student;

use App\Repositories\Base\BaseInterface;

interface StudentInterface extends BaseInterface {

}
