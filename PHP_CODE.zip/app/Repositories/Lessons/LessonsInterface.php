<?php

namespace App\Repositories\Lessons;

use App\Repositories\Base\BaseInterface;

interface LessonsInterface extends BaseInterface {

}
