<?php

namespace App\Repositories\ClassGroup;

use App\Repositories\Base\BaseInterface;

interface ClassGroupInterface extends BaseInterface {

}
