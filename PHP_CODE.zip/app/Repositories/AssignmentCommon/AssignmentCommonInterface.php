<?php

namespace App\Repositories\AssignmentCommon;

use App\Repositories\Base\BaseInterface;

interface AssignmentCommonInterface extends BaseInterface {

}
