<?php

namespace App\Repositories\ElectiveSubjectGroup;

use App\Repositories\Base\BaseInterface;

interface ElectiveSubjectGroupInterface extends BaseInterface {

}
