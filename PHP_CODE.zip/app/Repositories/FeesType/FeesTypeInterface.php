<?php

namespace App\Repositories\FeesType;

use App\Repositories\Base\BaseInterface;

interface FeesTypeInterface extends BaseInterface {

}
