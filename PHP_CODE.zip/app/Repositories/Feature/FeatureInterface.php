<?php

namespace App\Repositories\Feature;

use App\Repositories\Base\BaseInterface;

interface FeatureInterface extends BaseInterface {

}
