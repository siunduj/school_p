<?php

namespace App\Repositories\LessonsCommon;

use App\Repositories\Base\BaseInterface;

interface LessonsCommonInterface extends BaseInterface {

}
