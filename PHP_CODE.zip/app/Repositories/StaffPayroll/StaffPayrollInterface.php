<?php

namespace App\Repositories\StaffPayroll;

use App\Repositories\Base\BaseInterface;

interface StaffPayrollInterface extends BaseInterface {

}
