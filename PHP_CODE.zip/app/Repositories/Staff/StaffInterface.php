<?php

namespace App\Repositories\Staff;

use App\Repositories\Base\BaseInterface;

interface StaffInterface extends BaseInterface {

}
