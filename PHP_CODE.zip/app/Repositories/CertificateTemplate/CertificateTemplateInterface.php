<?php

namespace App\Repositories\CertificateTemplate;

use App\Repositories\Base\BaseInterface;

interface CertificateTemplateInterface extends BaseInterface {

}

