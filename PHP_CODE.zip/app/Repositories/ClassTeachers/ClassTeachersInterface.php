<?php

namespace App\Repositories\ClassTeachers;

use App\Repositories\Base\BaseInterface;

interface ClassTeachersInterface extends BaseInterface {

}
