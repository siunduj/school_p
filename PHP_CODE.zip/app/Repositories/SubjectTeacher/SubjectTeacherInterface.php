<?php

namespace App\Repositories\SubjectTeacher;

use App\Repositories\Base\BaseInterface;

interface SubjectTeacherInterface extends BaseInterface {

}
