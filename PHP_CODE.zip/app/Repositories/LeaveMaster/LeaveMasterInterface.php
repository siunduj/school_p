<?php

namespace App\Repositories\LeaveMaster;

use App\Repositories\Base\BaseInterface;

interface LeaveMasterInterface extends BaseInterface {

}
