<?php

namespace App\Repositories\OnlineExamStudentAnswer;

use App\Repositories\Base\BaseInterface;

interface OnlineExamStudentAnswerInterface extends BaseInterface {

}
