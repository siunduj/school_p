<?php

namespace App\Repositories\UserStatusForNextCycle;

use App\Repositories\Base\BaseInterface;

interface UserStatusForNextCycleInterface extends BaseInterface {

}
