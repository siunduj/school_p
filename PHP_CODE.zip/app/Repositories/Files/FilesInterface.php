<?php

namespace App\Repositories\Files;

use App\Repositories\Base\BaseInterface;

interface FilesInterface extends BaseInterface {

}
