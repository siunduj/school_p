<?php

namespace App\Repositories\SchoolInquiry;

use App\Repositories\Base\BaseInterface;

interface SchoolInquiryInterface extends BaseInterface {

}
