<?php

namespace App\Repositories\Holiday;

use App\Repositories\Base\BaseInterface;

interface HolidayInterface extends BaseInterface {

}
