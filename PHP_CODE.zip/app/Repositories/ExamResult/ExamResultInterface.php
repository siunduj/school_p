<?php

namespace App\Repositories\ExamResult;

use App\Repositories\Base\BaseInterface;

interface ExamResultInterface extends BaseInterface {

}
