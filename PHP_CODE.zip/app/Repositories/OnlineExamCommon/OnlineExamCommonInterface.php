<?php

namespace App\Repositories\OnlineExamCommon;

use App\Repositories\Base\BaseInterface;

interface OnlineExamCommonInterface extends BaseInterface {

}
