<?php

namespace App\Repositories\Medium;

use App\Repositories\Base\BaseInterface;

interface MediumInterface extends BaseInterface {

}
