<?php

namespace App\Repositories\Timetable;

use App\Repositories\Base\BaseInterface;

interface TimetableInterface extends BaseInterface
{

}
