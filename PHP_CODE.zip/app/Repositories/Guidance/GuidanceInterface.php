<?php

namespace App\Repositories\Guidance;

use App\Repositories\Base\BaseInterface;

interface GuidanceInterface extends BaseInterface {

}
