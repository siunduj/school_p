<?php

namespace App\Repositories\Attachment;

use App\Repositories\Base\BaseInterface;

interface AttachmentInterface extends BaseInterface {

}
