<?php

namespace App\Repositories\Announcement;

use App\Repositories\Base\BaseInterface;

interface AnnouncementInterface extends BaseInterface {

}
