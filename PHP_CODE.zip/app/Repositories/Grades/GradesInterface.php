<?php

namespace App\Repositories\Grades;

use App\Repositories\Base\BaseInterface;

interface GradesInterface extends BaseInterface {

}
