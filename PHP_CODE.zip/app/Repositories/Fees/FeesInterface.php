<?php

namespace App\Repositories\Fees;

use App\Repositories\Base\BaseInterface;

interface FeesInterface extends BaseInterface {

}
