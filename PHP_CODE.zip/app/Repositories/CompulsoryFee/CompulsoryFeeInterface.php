<?php

namespace App\Repositories\CompulsoryFee;

use App\Repositories\Base\BaseInterface;

interface CompulsoryFeeInterface extends BaseInterface {

}
