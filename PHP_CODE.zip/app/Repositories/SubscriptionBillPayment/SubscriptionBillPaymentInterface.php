<?php

namespace App\Repositories\SubscriptionBillPayment;

use App\Repositories\Base\BaseInterface;

interface SubscriptionBillPaymentInterface extends BaseInterface
{

}
