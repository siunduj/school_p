<?php

namespace App\Repositories\Section;

use App\Repositories\Base\BaseInterface;

interface SectionInterface extends BaseInterface {

}
