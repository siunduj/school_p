<?php

namespace App\Repositories\Message;

use App\Repositories\Base\BaseInterface;

interface MessageInterface extends BaseInterface {

}
