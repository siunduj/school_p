<?php

namespace App\Repositories\TopicCommon;

use App\Repositories\Base\BaseInterface;

interface TopicCommonInterface extends BaseInterface {

}
