<?php

namespace App\Repositories\StaffSalary;

use App\Repositories\Base\BaseInterface;

interface StaffSalaryInterface extends BaseInterface {

}
